#include<stdio.h>
void main()
{
    int x,y,sum;
    printf("enter the value of x and y");
    scanf("%d%d",&x,&y);
    sum=x+y;
    printf("sum=%d",sum);
}
