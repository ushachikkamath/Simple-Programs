#include<stdio.h>
int maximum(int[],int);
void main()
{
    int n,r,i;
    printf("enter the number of elements");
    scanf("%d",&n);
    int nu[n];
    printf("enter the %d elements",n);
    for(i=0;i<n;i++)
    {
       scanf("%d",&nu[i]);
    }
    r=maximum(nu,n);
    printf("%d is maximum number",r);
}

int maximum(int nu[],int n)
{
    int max=nu[0],i;
    for(i=1;i<n;i++)
    {

        if(nu[i]>max)
        {
            max=nu[i];

        }
    }
    return max;
}
/*#include<stdio.h>

int maximum(int[], int);

void main() {
    int n, r;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int nu[n];
    printf("Enter the %d elements: ", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &nu[i]);
    }

    r = maximum(nu, n);
    printf("%d is the maximum number.\n", r);
}

int maximum(int nu[], int n) {
    int max = nu[0];
    for (int i = 1; i < n; i++) {
        if (nu[i] > max) {
            max = nu[i];
        }
    }
    return max;
}


/*#include <stdio.h>

int main() {
    int n, i;
    int max = -2147483648; // Initialize max to the smallest possible integer value

    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int numbers[n];

    printf("Enter %d integers:\n", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &numbers[i]);

        // Check if the current number is greater than the current maximum
        if (numbers[i] > max) {
            max = numbers[i];
        }
    }

    printf("The maximum number is: %d\n", max);

    return 0;
}
*/
