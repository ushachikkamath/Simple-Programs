#include<stdio.h>
void main()
{
    int n;
    printf("enter the value of n");
    scanf("%d",&n);
    if(n%2==0)
    {
        printf("even number");
    }
    else
    {
        printf("odd number");
    }
}
