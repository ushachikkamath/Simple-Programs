#include<stdio.h>
void main()
{
    float area,radius;
    printf("enter the value of radius");
    scanf("%f",&radius);
    area=3.14*radius*radius;
    printf("area of circle=%f",area);
}
