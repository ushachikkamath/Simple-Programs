#include<stdio.h>
void main()
{
    int n,i;
    printf("enter the value of n");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        if(n>=10)
        {
            printf("dsa\n");
        }
        else
        {
            printf("c");
        }
    }
}
