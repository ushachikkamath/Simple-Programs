#include<stdio.h>
void main()
{
    printf("HELLOWORLD");
}
