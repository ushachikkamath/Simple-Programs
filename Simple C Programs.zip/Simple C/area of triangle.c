#include<stdio.h>
void main()
{
    float area,base,height;
    printf("enter the value of base and height");
    scanf("%f%f",&base,&height);
    area=0.5*base*height;
    printf("area of triangle=%f",area);
}
